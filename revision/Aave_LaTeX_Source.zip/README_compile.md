# Compile the revised manuscript

Install complete TeX Live with XeLaTeX. From this archive root:

```bash
cd paper
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

The full research package contains the data-driven paper builder and experimental code. This smaller archive contains final LaTeX, its cited bibliography, preamble and figures. The paper is a scientific-review version with unresolved chain/HF validation.
